#include <stdio.h>
int main() {
for (int i = 0; i < 2; i++) {
printf("Shoolini\n");
for (int j = 0; j <= 2; j++) {
printf("Btech CSE\n");
}
}
return 0;
}