#include <stdio.h>
int main(){
    int a,b;
    printf("Enter the first no.");
    scanf("%d",&a);
    printf("Enter the second no.");
    scanf("%d",&b);
    if(a>b){
    printf("%d",a);
    }
    else{
    printf("%d",b);
    }
    return 0;
}
