#include <stdio.h>
int main() {
int num, count = 0;
printf("Enter any number: ");
scanf("%d", &num);
if (num == 0) count = 1;
while (num != 0) { num /= 10; count++; }
printf("The total number of digits is %d\n", count);
return 0;
}